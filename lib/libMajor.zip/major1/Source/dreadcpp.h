extern "C"
{
	#include "dread.h"
}
